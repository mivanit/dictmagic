__version__ = "v0.1.0"
__description__ = "a package that makes it easier to do weird things with python dictionaries"

from .obj import ObjectDict,dictObj,gen_instance_ctor
from .paths import flatten,unflatten